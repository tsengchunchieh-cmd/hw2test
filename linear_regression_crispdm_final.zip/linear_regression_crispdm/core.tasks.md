# Core Tasks — Breakdown of Work

- Documentation: core.*.md files
- Backend: data generation, model fitting, metrics
- Frontend: Streamlit and Flask UIs
- Deployment: requirements, Procfile
