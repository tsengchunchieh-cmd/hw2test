# Core Prompt — Teaching Guidance

## Prompts by CRISP-DM Stage

1. Business Understanding
> What relationship do you expect between x and y?

2. Data Understanding
> How does noise affect the visibility of the trend?

3. Data Preparation
> Why split into training and testing sets?

4. Modeling
> Adjust slope and noise — how do learned coefficients change?

5. Evaluation
> What happens to R2 when noise increases?

6. Deployment
> How would you explain these results to a beginner?
