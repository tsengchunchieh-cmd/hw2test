# Core Summary — Project Recap

An interactive CRISP-DM demo for Simple Linear Regression, with Streamlit and Flask frontends and full Speckit-style documentation.
