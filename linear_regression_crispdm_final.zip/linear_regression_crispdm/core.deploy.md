# Core Deployment — Web Hosting

## Streamlit
streamlit run app.py

## Flask
web: gunicorn app_flask:app
