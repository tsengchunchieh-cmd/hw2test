# app.py
# Simple Linear Regression Demo (CRISP-DM)
# Framework: Streamlit
# ------------------------------------------

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

# ------------------------------
# PAGE CONFIG
# ------------------------------
st.set_page_config(page_title="Simple Linear Regression (CRISP-DM)", layout="wide")

st.title("Simple Linear Regression — CRISP-DM Interactive Demo")
st.write("This demo follows the CRISP-DM process to explain linear regression step by step.")

# ------------------------------
# SIDEBAR PARAMETERS
# ------------------------------
st.sidebar.header("Model Parameters")
a = st.sidebar.slider("Slope (a)", -10.0, 10.0, 2.0, 0.1)
b = st.sidebar.number_input("Intercept (b)", value=5.0, step=0.5)
noise_level = st.sidebar.slider("Noise level", 0.0, 5.0, 1.0, 0.1)
num_points = st.sidebar.slider("Number of points", 10, 300, 50, 10)
random_seed = st.sidebar.number_input("Random seed", value=42)

# ------------------------------
# 1) BUSINESS UNDERSTANDING
# ------------------------------
st.header("1) Business Understanding")
st.markdown("""
**Goal:**  
Understand how a linear model (y = ax + b) predicts continuous outcomes.

**Prompt:**  
- What is the relationship between x and y?  
- How might noise affect prediction accuracy?
""")

# ------------------------------
# 2) DATA UNDERSTANDING
# ------------------------------
st.header("2) Data Understanding")

np.random.seed(int(random_seed))
X = np.random.rand(num_points, 1) * 10
y_true = a * X + b
y = y_true + np.random.randn(num_points, 1) * noise_level

data = pd.DataFrame({"x": X.flatten(), "y": y.flatten()})
st.write("Sample of generated data")
st.dataframe(data.head())

fig, ax = plt.subplots()
ax.scatter(X, y, label="Data points", alpha=0.7)
ax.plot(X, y_true, color="red", label=f"True line (a={a}, b={b})")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.legend()
st.pyplot(fig)

st.info("Observe how noise affects the clarity of the trend line.")

# ------------------------------
# 3) DATA PREPARATION
# ------------------------------
st.header("3) Data Preparation")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=int(random_seed))
st.markdown(f"""
- Training samples: {len(X_train)}  
- Testing samples: {len(X_test)}  
- Data split 80/20 for training/testing
""")

# ------------------------------
# 4) MODELING
# ------------------------------
st.header("4) Modeling")

model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

st.success("Model trained successfully!")

fig2, ax2 = plt.subplots()
ax2.scatter(X_train, y_train, label="Train data", alpha=0.6)
ax2.scatter(X_test, y_test, label="Test data", alpha=0.6)
xs_full = np.linspace(X.min(), X.max(), 100).reshape(-1,1)
ys_full = model.predict(xs_full)
ax2.plot(xs_full, ys_full, color="red", label="Regression line")
ax2.set_xlabel("X")
ax2.set_ylabel("Y")
ax2.legend()
st.pyplot(fig2)

st.write("Learned Parameters:")
st.json({
    "Slope (a_hat)": float(model.coef_[0]),
    "Intercept (b_hat)": float(model.intercept_)
})

# ------------------------------
# 5) EVALUATION
# ------------------------------
st.header("5) Evaluation")

mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

st.metric("Mean Squared Error (MSE)", f"{mse:.3f}")
st.metric("R2 Score", f"{r2:.3f}")

st.markdown("""
**Prompt:**  
- Does the model fit well?  
- How does increasing noise or changing slope affect R2?
""")

residuals = y_test - y_pred
fig3, ax3 = plt.subplots()
ax3.scatter(y_pred, residuals, alpha=0.7)
ax3.axhline(0, color='red', linestyle='--')
ax3.set_xlabel("Predicted Y")
ax3.set_ylabel("Residuals")
st.pyplot(fig3)

# ------------------------------
# 6) DEPLOYMENT
# ------------------------------
st.header("6) Deployment")

st.markdown("""
You can deploy this app using:
- Streamlit Cloud (push to GitHub -> deploy)
- Render / Railway / HuggingFace Spaces

Prompt:
- How can this model be used to explain real-world regression problems?
""")

st.download_button(
    label="Download Dataset (CSV)",
    data=data.to_csv(index=False).encode('utf-8'),
    file_name='linear_data.csv',
    mime='text/csv'
)

st.success("CRISP-DM process completed!")

# PDF export feature can be added here using fpdf/BytesIO for Streamlit download_button


# PDF export implementation
from fpdf import FPDF
import io

if st.button("📄 Export Regression Report to PDF"):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Linear Regression Report", ln=True, align="C")

    pdf.set_font("Arial", "", 12)
    pdf.ln(5)
    pdf.cell(0, 10, f"Slope (a_hat): {float(model.coef_[0]):.3f}", ln=True)
    pdf.cell(0, 10, f"Intercept (b_hat): {float(model.intercept_):.3f}", ln=True)
    pdf.cell(0, 10, f"MSE: {mse:.3f}", ln=True)
    pdf.cell(0, 10, f"R2 Score: {r2:.3f}", ln=True)
    pdf.ln(5)

    for fig in [fig, fig2, fig3]:
        buf = io.BytesIO()
        fig.savefig(buf, format="PNG")
        buf.seek(0)
        pdf.image(buf, w=pdf.w - 40)
        buf.close()

    pdf_bytes = io.BytesIO()
    pdf.output(pdf_bytes)
    pdf_bytes.seek(0)

    st.download_button(
        label="Download PDF Report",
        data=pdf_bytes,
        file_name="regression_report.pdf",
        mime="application/pdf"
    )
