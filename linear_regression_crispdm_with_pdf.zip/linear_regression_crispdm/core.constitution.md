# Core Constitution — Simple Linear Regression (CRISP-DM)

## Purpose
To create an educational and interactive web-based system that demonstrates the Simple Linear Regression process using CRISP-DM.

## Vision
Help learners understand regression behavior under varying conditions by direct interaction.

## Mission
Integrate statistical modeling, visualization, and CRISP-DM teaching prompts in a modular web tool.
