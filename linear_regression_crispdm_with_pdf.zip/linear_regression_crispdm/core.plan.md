# Core Plan — Project Lifecycle

## Phase 1: Business Understanding
- Define goals and user controls (a, b, noise, num_points)

## Phase 2: Data Understanding
- Generate synthetic data and visualize

## Phase 3: Data Preparation
- Split into train/test

## Phase 4: Modeling
- Fit LinearRegression

## Phase 5: Evaluation
- Compute MSE and R2

## Phase 6: Deployment
- Streamlit and Flask versions
