# Simple Linear Regression — CRISP-DM Project

This package contains a teaching demo for simple linear regression following the CRISP-DM methodology.

Two web front-ends are included:
- Streamlit (`app.py`)
- Flask (`app_flask.py` with `templates/index.html`)

## Run Streamlit
```
pip install -r requirements.txt
streamlit run app.py
```

## Run Flask
```
pip install -r requirements.txt
python app_flask.py
# then visit http://127.0.0.1:5000
```

## Files
- `app.py` Streamlit app
- `app_flask.py` Flask app
- `templates/index.html` Flask template
- core.*.md documentation files
- `requirements.txt`
