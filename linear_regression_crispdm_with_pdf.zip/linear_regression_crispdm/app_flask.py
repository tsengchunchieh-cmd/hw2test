# app_flask.py
# Simple Linear Regression Demo (CRISP-DM)
# Framework: Flask
# ------------------------------------------

from flask import Flask, render_template, request, send_file
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io, base64, os

app = Flask(__name__)

def plot_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches='tight')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    buf.close()
    return image_base64

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    plot_data = None
    plot_model = None
    plot_residuals = None
    csv_path = None

    a = 2.0
    b = 5.0
    noise = 1.0
    num_points = 50
    seed = 42

    if request.method == "POST":
        a = float(request.form.get("a", 2.0))
        b = float(request.form.get("b", 5.0))
        noise = float(request.form.get("noise", 1.0))
        num_points = int(request.form.get("num_points", 50))
        seed = int(request.form.get("seed", 42))

        np.random.seed(seed)
        X = np.random.rand(num_points, 1) * 10
        y_true = a * X + b
        y = y_true + np.random.randn(num_points, 1) * noise
        data = pd.DataFrame({"x": X.flatten(), "y": y.flatten()})

        csv_path = os.path.join('static', 'linear_data.csv')
        os.makedirs('static', exist_ok=True)
        data.to_csv(csv_path, index=False)

        fig1, ax1 = plt.subplots()
        ax1.scatter(X, y, label="Data", alpha=0.7)
        ax1.plot(X, y_true, color="red", label="True line")
        ax1.set_xlabel("X")
        ax1.set_ylabel("Y")
        ax1.legend()
        plot_data = plot_to_base64(fig1)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=seed)
        model = LinearRegression().fit(X_train, y_train)
        y_pred = model.predict(X_test)
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)

        fig2, ax2 = plt.subplots()
        ax2.scatter(X_train, y_train, label="Train data", alpha=0.6)
        ax2.scatter(X_test, y_test, label="Test data", alpha=0.6)
        xs_full = np.linspace(X.min(), X.max(), 100).reshape(-1,1)
        ys_full = model.predict(xs_full)
        ax2.plot(xs_full, ys_full, color="red", label="Regression line")
        ax2.set_xlabel("X")
        ax2.set_ylabel("Y")
        ax2.legend()
        plot_model = plot_to_base64(fig2)

        residuals = y_test - y_pred
        fig3, ax3 = plt.subplots()
        ax3.scatter(y_pred, residuals, alpha=0.7)
        ax3.axhline(0, color='red', linestyle='--')
        ax3.set_xlabel("Predicted Y")
        ax3.set_ylabel("Residuals")
        plot_residuals = plot_to_base64(fig3)

        result = {
            "a": a,
            "b": b,
            "noise": noise,
            "num_points": num_points,
            "coef": float(model.coef_[0]),
            "intercept": float(model.intercept_),
            "mse": round(mse, 3),
            "r2": round(r2, 3),
            "csv": csv_path
        }

    return render_template(
        "index.html",
        result=result,
        plot_data=plot_data,
        plot_model=plot_model,
        plot_residuals=plot_residuals
    )

@app.route("/download")
def download():
    path = os.path.join('static', 'linear_data.csv')
    if os.path.exists(path):
        return send_file(path, as_attachment=True)
    return "No CSV available. Run a regression first.", 404

if __name__ == "__main__":
    app.run(debug=True)

# PDF export route can be added here using fpdf and Flask make_response
