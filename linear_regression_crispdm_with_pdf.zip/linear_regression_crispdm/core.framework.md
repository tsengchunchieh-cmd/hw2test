# Core Framework — Architecture

User -> Web UI (Streamlit/Flask) -> Controller (app.py/app_flask.py) -> Model (sklearn) -> Visualization -> Output
