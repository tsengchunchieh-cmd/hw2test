# Core Workflow — CRISP-DM Steps

1. Business Understanding: define objective and prompts
2. Data Understanding: generate and inspect data
3. Data Preparation: split datasets
4. Modeling: fit and predict
5. Evaluation: MSE, R2, residuals
6. Deployment: run web apps and serve
